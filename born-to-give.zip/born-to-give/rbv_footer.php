<!-- Site Footer -->
    <div class="site-footer parallax parallax3" style="background-image:url(images/parallax3.jpg)">
                            <div class="text-align-center">
                                <h2 class="block-title block-title-center" style="color:#fff;">Contact</h2>
                                <div id="section-contact" style="padding-top:10px"> &nbsp;</div>       
                            </div>
    	<div class="container">
        	<div class="row">
            	<div class="col-md-4 col-sm-4">
                	<div class="widget footer_widget text-center">
                    	<h4 class="widgettitle">Mumbai</h4>
                        <p>#301 , 3rd Floor<br>Hi-Tech I.T Park (Satya House),<br>
                            45, D.E., Ram Tekdi Road, <br>
                            Near Lodha Aria, Sewri West, <br>
                            Mumbai - 400015<br>
                        </p>
                    </div>
                </div>
            	<div class="col-md-4 col-sm-4">
                	<div class="widget footer_widget text-center">
                        <h4 class="widgettitle">Hyderabad</h4>
                        <p>265H, Road No.10 <br>
                                Jubilee Hills, <br>Hyderabad - 500 033 <br>
                                +91 85 0069 9829
                        </p>
                    </div>
                </div>
            	<div class="col-md-4 col-sm-4">
                	<div class="widget footer_widget text-center">
                        <h4 class="widgettitle">Bangalore</h4>
                        <p>#307, 3rd Floor <br>
                                No. 334,27th Main Road,<br> 2nd Sector, HSR Layout <br>
                                Bangalore - 560102
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Site Footer -->
    <div class="site-footer-bottom">
    	<div class="container">
        	<div class="row">
            	<div class="col-md-6 col-sm-6">
                	<div class="copyrights-col-left">
                    	<p>&copy; 2020 Riverbridge Initiatives. All Rights Reserved</p>
                    </div>
                </div>
            	<div class="col-md-6 col-sm-6"></div>
                	<div class="copyrights-col-right">
						<ul class="social-icons-rounded social-icons-colored" style="float:right;">
                            <li class="facebook"><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                            <li class="twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li class="googleplus"><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            <li class="youtube"><a href="#"><i class="fa fa-youtube-play"></i></a></li>
                            <li class="vimeo"><a href="#"><i class="fa fa-vimeo"></i></a></li>
                            <li class="instagram"><a href="#"><i class="fa fa-instagram"></i></a></li>
                        </ul>
                    	<!-- <ul class="footer-menu">
                        	<li><a href="privacy-policy.html">Privacy policy</a></li>
                        	<li><a href="payment-terms.html">Payment terms</a></li>
                        	<li><a href="refund-policy.html">Refund policy</a></li>
                        </ul> commented by punit 15 April 2020 -->
                    </div>
           	</div>
      	</div>
  	</div>
  	<a id="back-to-top"><i class="fa fa-angle-double-up"></i></a> 